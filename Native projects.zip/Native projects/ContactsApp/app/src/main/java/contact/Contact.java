package contact;

public class Contact {
    String Name = "";
    String LastName = "";
    String Email = "";

    public Contact(String name, String lastName, String email){
        this.Name = name;
        this.LastName = lastName;
        this.Email = email;
    }

    public String greetContact(){
        return "Hello " + this.Name + " " + this.LastName;
    }

    public String byeContact(){
        return "Goodbye " + this.Name + " " + this.LastName;
    }
}
