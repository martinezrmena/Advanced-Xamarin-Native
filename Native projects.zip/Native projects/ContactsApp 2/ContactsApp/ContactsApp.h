//
//  ContactsApp.h
//  ContactsApp
//
//  Created by Eduardo Rosas on 10/15/18.
//  Copyright © 2018 Eduardo Rosas. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ContactsApp : NSObject

@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *lastname;
@property (nonatomic, strong) NSString *email;

- (id)initWithName:(NSString *)name
          lastname:(NSString *)lastname
             email:(NSString *)email;
- (NSString *)greetContact;
- (NSString *)byeContact;

@end
